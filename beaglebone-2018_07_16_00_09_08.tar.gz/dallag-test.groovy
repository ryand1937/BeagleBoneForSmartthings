/*
 *  Device handler to communicate with the beaglebone black wireless (or any embedded linux device)
 * 
 *  Some functions taken from:
 *  LANnouncer Alerter (Formerly LANdroid - but Google didn't like that much.)
 *  Version 1.25 22 July 2016
 *  Copyright 2015-2016 Tony McNamara
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 *
 */
import groovy.json.JsonSlurper

metadata {
    definition (name: "Beaglebone", namespace: "dallago", author: "Ryan Dallago") {
        capability "Light"
        capability "Alarm"
        capability "refresh"
        capability "temperatureMeasurement"
        capability "Actuator"
        capability "Switch Level"
         
        command "setFreq", ["number"]
        command "setServo", ["number"]
        command "setPWMEn"
        command "setPWMDis"
        command "playaudio"
        command "stopaudio"
    }
    
    preferences {
        input("DeviceLocalLan", "string", title:"Device IP Address", description:"Device's I.P. address", defaultValue:"" , required: false, displayDuringSetup: true)
        input("DevicePort", "string", title:"Device Port", description:"Port the device listens on", defaultValue:"1035", required: false, displayDuringSetup: true)
        input("BoolTest", "bool", title:"Do nothing", description:"Example of a boolean input", defaultValue: true, displayDuringSetup: true)
    }

    tiles(scale: 2) {
        standardTile("light", "device.light", width: 2, height: 2) {
            state "off", label:'Off', action:'light.on', icon:"st.Lighting.light13", backgroundColor:"#ffffff"
            state "on", label:'On', action:'light.off', icon:"st.Lighting.light11", backgroundColor:"#e8a213"
        }
		standardTile("refresh", "device.temperature", inactiveLabel: false, decoration: "flat", width: 2, height: 2) {
			state "default", label: '', action: "refresh.refresh", icon: "st.secondary.refresh"
		}
		valueTile("temperature", "device.temperature", width: 2, height: 2) {
       		 state "val", label:'${currentValue}', defaultState: true
   		 }
        standardTile("pwmEnable", "device.pwmStatus", height: 2, width: 2, inactiveLabel: false) {
			state "on", action:'setPWMDis', label:"pwm on"
            state "off", action:'setPWMEn', label:"pwm off"
		}
        controlTile("pwmDutySlider", "device.level", "slider", decoration: "flat", height: 2, width: 2, inactiveLabel: false) {
			state "level", action:"switch level.setLevel", label:'${currentValue}',unit:"%"
		}
        controlTile("pwmFreqSlider", "device.status", "slider", decoration: "flat",range:"(1000..1000000)", height: 2, width: 2, inactiveLabel: false) {
			state "freq", action:"setFreq", label:'${currentValue}', unit: "Hz"
		}
        controlTile("ServoSlider", "device.angle", "slider", decoration: "flat",range:"(-90..90)", height: 2, width: 2, inactiveLabel: false) {
			state "angle", action:"setServo", label:'${currentValue}',unit:"Deg"
		}
		standardTile("alarm", "device.alarm", height: 2, width: 2, inactiveLabel: false) {
			state "off", action: 'alarm.both', label: "Play Sound", nextState: "both"
            state "both", action: 'alarm.stopaudio', label:"Playing", nextState: "off"
           
		}
		
        main (["alarm", "light", "temperature"]);
        details(["light", "pwmEnable","temperature", 
        		"pwmDutySlider",
                "pwmFreqSlider",
                "ServoSlider",
                "alarm",
                "refresh"]);
    }



}
def stopaudio(){
	log.debug "Stopping audio"
}

def both(){
    log.debug "Playing Audio the temperature"
    def command=("PLAY=X")+getDoneString();
    return	sendCommands(command);
}

def get_temp(){
    log.debug "Requesting the temperature"
    def command=("TEMP=X")+getDoneString();
    return	sendCommands(command);
}

def refresh() {
	log.debug "refresh pressed"
    get_temp()
    
}
/** 
 * Light Capability, ON/Off. 
**/
def off() {
    log.debug "Turning Light off"
    
    sendEvent(name:"light", value:"off")
    def command=("LIGHT=OFF")+getDoneString()
    return sendCommands(command)
}
def on() {
	
    log.debug "Turning Light on"
    sendEvent(name:"light", value:"on")
    def command=("LIGHT=ON")+getDoneString();
    return sendCommands(command);
}

/** 
 * PWM Enable/Disable
**/
def setPWMEn()
{
	log.debug "setting PWM Enable to ON"
    sendEvent(name:"pwmStatus", value:"on") 
    
    def command=("PWMEN=ON")+getDoneString();
    return sendCommands(command);
}

def setPWMDis()
{
	log.debug "setting PWM Enable to OFF"
    sendEvent(name:"pwmStatus", value:"off") 
    
    def command=("PWMEN=OFF")+getDoneString();
    return sendCommands(command);
}
/** 
 * PWM Set Level
**/
def setLevel(value)
{
	log.debug "setting PWM level to $value %"
    sendEvent(name:"switch", value:"$value")
    def command=("PWM=$value")+getDoneString();
    return sendCommands(command);
}
/** 
 * Frequency Set Level
**/
def setFreq(value)
{
	log.debug "setting Frequency to $value"
    sendEvent(name:"status", value:"$value")
    def command=("FREQ=$value")+getDoneString();
    return sendCommands(command);
}

/*
* Set the Servo angle 
*/
def setServo(value)
{
	log.debug "setting Servo to $value"
    def result = 600000+(10000*(90+value))
    sendEvent(name:"angle", value:"$value")
    def command=("SERVO=$result")+getDoneString();
    return sendCommands(command);
}

/** Send to IP and to SMS as appropriate 
 *  The caller MUST return the value, which is the hubAction.
 *  As of version 1.25, does not "send" the command so much as 
 *  request that the calling service send it.
 */
private sendCommands(command) {
    log.info "Command request: "+command
  //  sendSMSCommand(command)
    return sendIPCommand(command)
}

/** Prepares the hubAction to be executed.
 *  Pre-V25, this was executed in-line.  
 *  Now it is returned, not executed, and must be returned up the calling chain.
 */
private sendIPCommand(commandString, sendToS3 = false) {
    log.info "Sending command "+ commandString+" to "+DeviceLocalLan+":"+DevicePort
    if (DeviceLocalLan?.trim()) {
        def hosthex = convertIPtoHex(DeviceLocalLan)
        def porthex = convertPortToHex(DevicePort)
        device.deviceNetworkId = "$hosthex:$porthex"

        def headers = [:] 
        headers.put("HOST", "$DeviceLocalLan:$DevicePort")

        def method = "GET"

        def hubAction = new physicalgraph.device.HubAction(
            method: method,
            path: "/"+commandString,
            headers: headers
            );
        if (sendToS3 == true)
        {
            hubAction.options = [outputMsgToS3:true];
        }
        log.debug hubAction
        return hubAction;
    }
}

private String getDoneString() {
    return "@DONE@"
}

def parse(String description) {
	def event
    log.debug "Parsing '${description}'"
      
    def map = parseLanMessage(description);
    log.debug "As LAN: " + map;
    log.debug "Header = " + map.header;
    log.debug "The Return Message Body = " + map.body;
    
    def slurper = new JsonSlurper()
    def result = slurper.parseText(map.body)
    log.debug "The result is: " + result

    if (result.containsKey("TEMP")) {
    	log.debug "found Temperature key"      
        event = createEvent(name:"temperature", value:result.TEMP)
    }
    if(result.containsKey("PWM_duty"))
    {
    	log.debug "found duty cycle key";
        event = createEvent(name: "level", value:result.PWM_duty)
    }
    if(result.containsKey("PWM_period"))
    {
    	log.debug "found PWM period key";
        event = createEvent(name: "staus", value:result.PWM_period)
    }
    if(result.containsKey("PWM_en"))
    {
    	log.debug "found PWM enable key";
      //  event= createEvent(name: "pwmStatus", value: result.PWMEN)
    }
    if(result.containsKey("SERVO_duty"))
    {
    	log.debug "found Servo angle set key";
        event= createEvent(name: "angle", value: result.SERVO_duty)
    }
    if(result.containsKey("PLAY"))
    {
    	log.debug "play key found"
        sendEvent(name:"alarm", value:"off")
        event = createEvent(name: "alarm", value:"off")
    }
    
    return event
}

private String convertIPtoHex(ipAddress) { 
    String hex = ipAddress.tokenize( '.' ).collect {  String.format( '%02X', it.toInteger() ) }.join()
    log.debug "IP address entered is $ipAddress and the converted hex code is $hex"
    return hex

}

private String convertPortToHex(port) {
    String hexport = port.toString().format( '%04X', port.toInteger() )
    log.debug hexport
    return hexport
}